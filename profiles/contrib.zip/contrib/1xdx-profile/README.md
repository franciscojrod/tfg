# 1xDX project

This is the Drupal 8 starter project of 1xINTERNET.

Use [Composer](https://getcomposer.org/) to get Drupal and all dependencies (currently profile is included in sourcecode).

Based on [1xInternet/1xdx-composer-project](https://git.1xinternet.de/1xInternet/1xdx-composer-project).

## Installation

Please check Readme.md file from [1xInternet/1xdx-composer-project](https://git.1xinternet.de/1xInternet/1xdx-composer-project).

## Particle theme

The [particle theme](https://git.1xinternet.de/1xInternet/1xdx-particle) is part of the starterkit and is enabled by default.

## Drush commands

- ```drush geis``` - command for creating new image styles  [details](web/profiles/custom/xi_profile/modules/xi_image_styles/README.md)

## Updating Drupal Core

This project will attempt to keep all of your Drupal Core files up-to-date; the 
project [drupal-composer/drupal-scaffold](https://github.com/drupal-composer/drupal-scaffold) 
is used to ensure that your scaffold files are updated every time drupal/core is 
updated. If you customize any of the "scaffolding" files (commonly .htaccess), 
you may need to merge conflicts if any of your modified files are updated in a 
new release of Drupal core.

Follow the steps below to update your core files.

1. Run `composer update drupal/core symfony/* --with-dependencies` to update Drupal Core and its dependencies.
1. Run `git diff` to determine if any of the scaffolding files have changed. 
   Review the files for any changes and restore any customizations to 
  `.htaccess` or `robots.txt`.
1. Commit everything all together in a single commit, so `web` will remain in
   sync with the `core` when checking out branches or running `git bisect`.
1. In the event that there are non-trivial conflicts in step 2, you may wish 
   to perform these steps on a branch, and use `git merge` to combine the 
   updated core files with your customized files. This facilitates the use 
   of a [three-way merge tool such as kdiff3](http://www.gitshah.com/2010/12/how-to-setup-kdiff-as-diff-tool-for-git.html). This setup is not necessary if your changes are simple; 
   keeping all of your modifications at the beginning or end of the file is a 
   good strategy to keep merges easy.

## Tests

Behat tests can be created in the features folder under the path tests/behat.

## FAQ

### Should I commit the contrib modules I download?

Composer recommends **no**. They provide [argumentation against but also
workrounds if a project decides to do it anyway](https://getcomposer.org/doc/faqs/should-i-commit-the-dependencies-in-my-vendor-directory.md).

### How can I apply patches to downloaded modules?

If you need to apply patches (depending on the project being modified, a pull
request is often a better solution), you can do so with the
[composer-patches](https://github.com/cweagans/composer-patches) plugin.

To add a patch to drupal module foobar insert the patches section in the extra
section of composer.json:
```json
"extra": {
    "patches": {
        "drupal/foobar": {
            "Patch description": "URL to patch"
        }
    }
}
```

### How can I add js/css libraries using composer.json?

It is possible to use frontend libraries with composer thanks to the
asset-packagist repository (https://asset-packagist.org/).

For example, to use colorbox:
```
composer require npm-asset/colorbox:"^0.4"

```
Composer will detect new versions of the library that meet your constraints.
In the above example it will download anything from 0.4.* series of colorbox.

When managing libraries with composer this way, you may not want to add it to
version control. In that case, add specific directories to the .gitignore file.
```
# Specific libraries (which we manage with composer)
web/libraries/colorbox
```
### How I can configure Environment Indicator Switcher?

1. Go to /admin/config/development/environment-indicator/switcher and add needed environments. Usually we are using:
- { name: "local", fg_color: "#fff", bg_color: "#000" }
- { name: "dev", fg_color: "#fff", bg_color: "#5a5a5a" }
- { name: "test", fg_color: "#4d7750", bg_color: "#1dea59" }
- { name: "stage", fg_color: "#642828", bg_color: "#f3f200" }
- { name: "live", fg_color: "#acf9ff", bg_color: "#ff0000" }
2. Add ```$config['environment_indicator.indicator']['name'] = 'Local';``` into settings.php file on each environment.

### How I can use paragraph behaviors?

#### Paragraph Zoom
Can be used in galleries, to enable/disable images zooming;
- Adding ```zoom``` property to a #paragraph object
#### Paragraph Width
 Can be used to define paragraph width. 
 - Provides three option: 'full', 'wide', 'narrow' 
 - Adding css class to a paragraph ```paragraph-$width```
 - Adding ```data-width``` attribute with choosen value e.q. 'full'
 #### Paragraph Invert
 Can be used for anything
 - Adding css class to a paragraph ```paragraph-invert```
 #### Paragraph Theme
Can be used for anything
- Provides three option: 'none', 'dark', 'light'
- Adding css class to a paragraph ```paragraph-$theme```
