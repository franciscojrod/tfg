# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Last login block to user dashboard.
- Persistent login enabled by default.
- Demo module is not enabled by default.
- Mail encryption module (dbee) is enabled by default.
- Create content from templates with quick clone module.
- Employee content type with xi_employee module.

### Changed
- Open "Content" tab by default on node edit form and "Preview" tab on node add form

## [1.1.3] - 2020-02-03

### Added
- Oiljs integration module (xi_privacy)
- Paragraph icons in admin theme

### Changed
- Media reference field opened by default
- Entity browser versio 2.x
- Combine all widgets in one entity browser (field_media_browser) and use access method to control appearance
- Media consent to local storage instead of cookies

## [1.1.2] - 2020-01-21

### Fixed
- Paragraph behaviours (summaries) and preprocesses.

### Added
- Image text paragraph
- Breadcrumb title field in xi_seo module.

## [1.1.1] - 2020-01-08

### Removed
- Fixed block content module and its blocks.

### Changed
- Admin toolbar updated to version 2.x.
- Banner image style ratio from 6:1 to 19:6
- Hero image style ratio from 16:9 to 19:9
- Photo image style ratio from 4:3 to 16:9

### Fixed
- DropZoneJS module patch for max file size.
- Field group warning on node edit page.
- Teaser entity view display

### Added
- Config Ignore Collections (to ignore language collections)
- Utility menu with demo content.
- Pathauto pattern for event content type.
- Pathauto pattern for news content type.
- Pathauto pattern for taxonomy terms.
- Lightbox integration for media gallery.

## [1.1.0] - 2019-12-05

### Changed
- Use core-supported composer method.

### Removed
- Imagemagick integration.

## [1.0.3] - 2019-11-28

### Changed
- Theme dependencies in profile
- CI able to deploy different branches to different environments

## [1.0.2] - 2019-11-27

### Rename
- Rename to lowercased name of packages

### Removed
- Local patch for ckeditor_bootstrap_grid

## [1.0.1] - 2019-10-30

### Fixed
- Config rewrites after contrib module update

## [1.0.0] - 2019-10-30

Initial commit
