(function (window, Drupal, $) {

  // Embedded media.
  Drupal.behaviors.embeddedMediaConsent = {
    attach: function (context, settings) {
      $(context).find('.embedded_media_consent').each(function() {
        var id = $(this).attr('id');
        var provider = $(this).data('provider');
        if (localStorage.getItem('Drupal.media_consent.cookie_agreed_' + provider) === '1') {
          if (typeof settings.embedded_media[id] !== 'undefined') {
            $(this).removeClass('embedded_media_consent');
            $(this).html(settings.embedded_media[id]);
          }
        } else {
          $(this).one('click', function () {
            if (typeof settings.embedded_media[id] !== 'undefined') {
              $(this).removeClass('embedded_media_consent');
              $(this).html(settings.embedded_media[id]);
              localStorage.setItem('Drupal.media_consent.cookie_agreed_' + provider, 1);
            }
          });
        }
      });
    }
  };

}(window, window.Drupal, window.jQuery));
