/**
 * @file
 *
 * Adds additional javascript functionality to the admin ui.
 */
(function ($) {
  'use strict';

  Drupal.behaviors.admin_ui = {
    attach: function(context, settings) {
      // Overwrite the translation strings from the Dropzone library.
      if (typeof Dropzone !== 'undefined') {
        Dropzone.prototype.defaultOptions.dictInvalidFileType = Drupal.t("You can't upload files of this type.");
      }
    }
  };

}(jQuery));