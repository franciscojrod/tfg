(function (window, Drupal, $) {

// Embedded audios.
  Drupal.behaviors.embeddedAudios = {
    attach: function (context, settings) {
      // Initialize values on embedded audios.
      $('.c-audio').each(function () {
        var audio = $(this).find('audio')[0];

        // Volume to 50%.
        $(this).data('volume', 0.5);
        audio.volume = 0.5;

        var minutes = Math.floor(audio.duration / 60);
        var seconds = Math.floor(audio.duration - minutes * 60);
        $(this).find('.c-audio-duration').text(('0' + minutes).slice(-2) + ':' + ('0' + seconds).slice(-2));
      });
    }
  };

// Embedded audio behaviours.
  Drupal.behaviors.audio = {
    attach: function (context, settings) {
      // Play/pause.
      $('.c-audio .c-audio-play-pause', context).once('audioPlay').click(function () {
        var c_audio = $(this).closest('.c-audio');
        var audio = c_audio.find('audio')[0];

        if (audio.paused) {
          audio.play();
          $(this).addClass('pause');
        }
        else {
          $(this).removeClass('pause');
          audio.pause();
        }

        // Progress bar changes while in playback.
        audio.ontimeupdate = function () {
          var progress = c_audio.find('.c-audio-progress-current');
          progress.css('width', audio.currentTime / audio.duration * 100 + '%')
          var minutes = Math.floor(audio.currentTime / 60);
          var seconds = Math.floor(audio.currentTime - minutes * 60);
          c_audio.find('.c-audio-position').text(('0' + minutes).slice(-2) + ':' + ('0' + seconds).slice(-2));
        }

        // End of playing.
        audio.onended = function () {
          audio.currentTime = 0;
          c_audio.find('.c-audio-progress-current').width(0);
          c_audio.find('.c-audio-position').text('00:00');
          c_audio.find('.c-audio-play-pause').removeClass('pause');
        }
      });

      // Volume change.
      $('.c-audio .c-audio-volume', context).once('audioVolume').click(function (e) {
        var c_audio = $(this).closest('.c-audio');
        var audio = c_audio.find('audio')[0];

        // Set volume.
        var volume = (e.clientX - $(this).offset().left) / $(this).width();
        audio.volume = volume;

        // Button that indicates more volume than the middle.
        if (audio.volume > 0.5) {
          c_audio.find('.c-audio-volume-btn').addClass('up');
        }
        else {
          c_audio.find('.c-audio-volume-btn').removeClass('up');
        }

        // Set volume bar.
        $(this).find('.c-audio-volume-current').width(volume * 100 + '%');

        // Store volume so we can use with the mute button.
        c_audio.data('volume', volume);
      });

      // Progress change.
      $('.c-audio .c-audio-progress', context).once('audioProgress').click(function (e) {
        var c_audio = $(this).closest('.c-audio');
        var audio = c_audio.find('audio')[0];

        // Set progress.
        var progress = (e.clientX - $(this).offset().left) / $(this).width();
        audio.currentTime = progress * audio.duration;

        // Set progress bar.
        $(this).find('.c-audio-progress-current').width(progress * 100 + '%');
      });

      // Mute/un-mute.
      $('.c-audio .c-audio-volume-btn', context).once('audioVolumeMute').click(function (e) {
        var c_audio = $(this).closest('.c-audio');
        var audio = c_audio.find('audio')[0];

        if (c_audio.find('.c-audio-volume-current').width()) {
          c_audio.find('.c-audio-volume-current').width(0);
          $(this).addClass('mute');
          audio.volume = 0;
        }
        else {
          c_audio.find('.c-audio-volume-current').width(c_audio.data('volume') * 100 + '%');
          $(this).removeClass('mute');
          audio.volume = c_audio.data('volume');
        }
      });
    }
  };


}(window, window.Drupal, window.jQuery));