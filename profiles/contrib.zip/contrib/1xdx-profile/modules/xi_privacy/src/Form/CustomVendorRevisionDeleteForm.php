<?php

namespace Drupal\xi_privacy\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a form for deleting a Custom vendor revision.
 *
 * @ingroup xi_privacy
 */
class CustomVendorRevisionDeleteForm extends ConfirmFormBase {

  /**
   * The Custom vendor revision.
   *
   * @var \Drupal\xi_privacy\Entity\CustomVendorInterface
   */
  protected $revision;

  /**
   * The Custom vendor storage.
   *
   * @var \Drupal\Core\Entity\EntityStorageInterface
   */
  protected $customVendorStorage;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $connection;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->customVendorStorage = $container->get('entity_type.manager')->getStorage('custom_vendor');
    $instance->connection = $container->get('database');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'custom_vendor_revision_delete_confirm';
  }

  /**
   * {@inheritdoc}
   */
  public function getQuestion() {
    return $this->t('Are you sure you want to delete the revision from %revision-date?', [
      '%revision-date' => format_date($this->revision->getRevisionCreationTime()),
    ]);
  }

  /**
   * {@inheritdoc}
   */
  public function getCancelUrl() {
    return new Url('entity.custom_vendor.version_history', ['custom_vendor' => $this->revision->id()]);
  }

  /**
   * {@inheritdoc}
   */
  public function getConfirmText() {
    return $this->t('Delete');
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $custom_vendor_revision = NULL) {
    $this->revision = $this->CustomVendorStorage->loadRevision($custom_vendor_revision);
    $form = parent::buildForm($form, $form_state);

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->CustomVendorStorage->deleteRevision($this->revision->getRevisionId());

    $this->logger('content')->notice('Custom vendor: deleted %title revision %revision.', ['%title' => $this->revision->label(), '%revision' => $this->revision->getRevisionId()]);
    $this->messenger()->addMessage(t('Revision from %revision-date of Custom vendor %title has been deleted.', ['%revision-date' => format_date($this->revision->getRevisionCreationTime()), '%title' => $this->revision->label()]));
    $form_state->setRedirect(
      'entity.custom_vendor.canonical',
       ['custom_vendor' => $this->revision->id()]
    );
    if ($this->connection->query('SELECT COUNT(DISTINCT vid) FROM {custom_vendor_field_revision} WHERE id = :id', [':id' => $this->revision->id()])->fetchField() > 1) {
      $form_state->setRedirect(
        'entity.custom_vendor.version_history',
         ['custom_vendor' => $this->revision->id()]
      );
    }
  }

}
