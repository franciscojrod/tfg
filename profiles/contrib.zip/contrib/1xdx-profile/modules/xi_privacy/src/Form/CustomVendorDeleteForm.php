<?php

namespace Drupal\xi_privacy\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Custom vendor entities.
 *
 * @ingroup xi_privacy
 */
class CustomVendorDeleteForm extends ContentEntityDeleteForm {


}
