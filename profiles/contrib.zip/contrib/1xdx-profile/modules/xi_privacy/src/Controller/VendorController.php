<?php


namespace Drupal\xi_privacy\Controller;


use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Datetime\DrupalDateTime;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Serializer\SerializerInterface;

/**
* Class VendorController
 *
 * @package Drupal\xi_privacy\Controller
 */
class VendorController extends ControllerBase {

  /**
   * @var \Symfony\Component\Serializer\SerializerInterface
   */
  protected $serializer;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->serializer = $container->get('serializer');
    return $instance;
  }

  /**
   * Returns the list of custom vendors in oiljs format.
   */
  public function list() {
    $delta = [];
    $storage = $this->entityTypeManager()->getStorage('taxonomy_term');
    $query = $storage->getQuery();
    $query->condition('status', 1);
    $query->condition('vid', ['feature', 'purpose'], 'IN');
    $ids = $query->execute();
    $terms = $storage->loadMultiple($ids);
    $version_info = $this->state()->get('taxonomy_term_version', ['vendorListVersion' => 1, 'lastUpdated' => (new DrupalDateTime())->format('c')]);
    $result = [
      'vendors' => [],
      'purposes' => [],
      'features' => [],
    ] + $version_info;
    if (!empty($terms)) {
      foreach ($terms as $term) {
        // Build the index of term item in the response.
        // The ids of the data sent to oiljs needs to start with 1.
        $delta[$term->bundle()] = empty($delta[$term->bundle()]) ? 1 : ++$delta[$term->bundle()];
        $item = $term->toArray();
        $result[$term->bundle() . 's'][] = $this->cleanItem($item, $delta[$term->bundle()]);
      }
    }
    $cacheable_metadata = new CacheableMetadata();
    $cacheable_metadata->setCacheTags(['taxonomy_term_list']);
    $response = new CacheableJsonResponse($result);
    return $response->addCacheableDependency($cacheable_metadata);
  }

  /**
   * Keep only the relevant information about the taxonomy term.
   *
   * @param array $item
   *   The taxonomy term entity as array.
   * @param int $delta
   *   The index of the taxonomy term based on type.
   *
   * @return mixed
   */
  private function cleanItem(array $item, $delta) {
    foreach ($item as $key => $value) {
      if (!in_array($key, ['tid', 'name', 'description'])) {
        unset($item[$key]);
        continue;
      }
      switch ($key) {
        case 'tid':
          $item['id'] = $delta;
          unset($item['tid']);
          break;
        case 'name':
          $item['name'] = $item['name'][0]['value'];
          break;
        case 'description':
          $item['description'] = strip_tags($item['description'][0]['value']);
          break;
      }
    }
    return $item;
  }

}
