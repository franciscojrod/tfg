<?php

namespace Drupal\xi_privacy\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Url;
use Drupal\xi_privacy\Entity\CustomVendorInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class CustomVendorController.
 *
 *  Returns responses for Custom vendor routes.
 */
class CustomVendorController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The date formatter.
   *
   * @var \Drupal\Core\Datetime\DateFormatter
   */
  protected $dateFormatter;

  /**
   * The renderer.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $renderer;

  /**
   * The serializer.
   *
   * @var \Symfony\Component\Serializer\SerializerInterface
   */
  protected $serializer;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->dateFormatter = $container->get('date.formatter');
    $instance->renderer = $container->get('renderer');
    $instance->serializer = $container->get('serializer');
    return $instance;
  }

  /**
   * Displays a Custom vendor revision.
   *
   * @param int $custom_vendor_revision
   *   The Custom vendor revision ID.
   *
   * @return array
   *   An array suitable for drupal_render().
   */
  public function revisionShow($custom_vendor_revision) {
    $custom_vendor = $this->entityTypeManager()->getStorage('custom_vendor')
      ->loadRevision($custom_vendor_revision);
    $view_builder = $this->entityTypeManager()->getViewBuilder('custom_vendor');

    return $view_builder->view($custom_vendor);
  }

  /**
   * Page title callback for a Custom vendor revision.
   *
   * @param int $custom_vendor_revision
   *   The Custom vendor revision ID.
   *
   * @return string
   *   The page title.
   */
  public function revisionPageTitle($custom_vendor_revision) {
    $custom_vendor = $this->entityTypeManager()->getStorage('custom_vendor')
      ->loadRevision($custom_vendor_revision);
    return $this->t('Revision of %title from %date', [
      '%title' => $custom_vendor->label(),
      '%date' => $this->dateFormatter->format($custom_vendor->getRevisionCreationTime()),
    ]);
  }

  /**
   * Generates an overview table of older revisions of a Custom vendor.
   *
   * @param \Drupal\xi_privacy\Entity\CustomVendorInterface $custom_vendor
   *   A Custom vendor object.
   *
   * @return array
   *   An array as expected by drupal_render().
   */
  public function revisionOverview(CustomVendorInterface $custom_vendor) {
    $account = $this->currentUser();
    $custom_vendor_storage = $this->entityTypeManager()->getStorage('custom_vendor');

    $langcode = $custom_vendor->language()->getId();
    $langname = $custom_vendor->language()->getName();
    $languages = $custom_vendor->getTranslationLanguages();
    $has_translations = (count($languages) > 1);
    $build['#title'] = $has_translations ? $this->t('@langname revisions for %title', ['@langname' => $langname, '%title' => $custom_vendor->label()]) : $this->t('Revisions for %title', ['%title' => $custom_vendor->label()]);

    $header = [$this->t('Revision'), $this->t('Operations')];
    $revert_permission = (($account->hasPermission("revert all custom vendor revisions") || $account->hasPermission('administer custom vendor entities')));
    $delete_permission = (($account->hasPermission("delete all custom vendor revisions") || $account->hasPermission('administer custom vendor entities')));

    $rows = [];

    $vids = $custom_vendor_storage->revisionIds($custom_vendor);

    $latest_revision = TRUE;

    foreach (array_reverse($vids) as $vid) {
      /** @var \Drupal\xi_privacy\CustomVendorInterface $revision */
      $revision = $custom_vendor_storage->loadRevision($vid);
      // Only show revisions that are affected by the language that is being
      // displayed.
      if ($revision->hasTranslation($langcode) && $revision->getTranslation($langcode)->isRevisionTranslationAffected()) {
        $username = [
          '#theme' => 'username',
          '#account' => $revision->getRevisionUser(),
        ];

        // Use revision link to link to revisions that are not active.
        $date = $this->dateFormatter->format($revision->getRevisionCreationTime(), 'short');
        if ($vid != $custom_vendor->getRevisionId()) {
          $link = $this->l($date, new Url('entity.custom_vendor.revision', [
            'custom_vendor' => $custom_vendor->id(),
            'custom_vendor_revision' => $vid,
          ]));
        }
        else {
          $link = $custom_vendor->link($date);
        }

        $row = [];
        $column = [
          'data' => [
            '#type' => 'inline_template',
            '#template' => '{% trans %}{{ date }} by {{ username }}{% endtrans %}{% if message %}<p class="revision-log">{{ message }}</p>{% endif %}',
            '#context' => [
              'date' => $link,
              'username' => $this->renderer->renderPlain($username),
              'message' => [
                '#markup' => $revision->getRevisionLogMessage(),
                '#allowed_tags' => Xss::getHtmlTagList(),
              ],
            ],
          ],
        ];
        $row[] = $column;

        if ($latest_revision) {
          $row[] = [
            'data' => [
              '#prefix' => '<em>',
              '#markup' => $this->t('Current revision'),
              '#suffix' => '</em>',
            ],
          ];
          foreach ($row as &$current) {
            $current['class'] = ['revision-current'];
          }
          $latest_revision = FALSE;
        }
        else {
          $links = [];
          if ($revert_permission) {
            $links['revert'] = [
              'title' => $this->t('Revert'),
              'url' => $has_translations ?
              Url::fromRoute('entity.custom_vendor.translation_revert', [
                'custom_vendor' => $custom_vendor->id(),
                'custom_vendor_revision' => $vid,
                'langcode' => $langcode,
              ]) :
              Url::fromRoute('entity.custom_vendor.revision_revert', [
                'custom_vendor' => $custom_vendor->id(),
                'custom_vendor_revision' => $vid,
              ]),
            ];
          }

          if ($delete_permission) {
            $links['delete'] = [
              'title' => $this->t('Delete'),
              'url' => Url::fromRoute('entity.custom_vendor.revision_delete', [
                'custom_vendor' => $custom_vendor->id(),
                'custom_vendor_revision' => $vid,
              ]),
            ];
          }

          $row[] = [
            'data' => [
              '#type' => 'operations',
              '#links' => $links,
            ],
          ];
        }

        $rows[] = $row;
      }
    }

    $build['custom_vendor_revisions_table'] = [
      '#theme' => 'table',
      '#rows' => $rows,
      '#header' => $header,
    ];

    return $build;
  }

  /**
   * Returns the list of custom vendors in oiljs format.
   */
  public function list() {
    $storage = $this->entityTypeManager()->getStorage('custom_vendor');
    $query = $storage->getQuery();
    $query->condition('status', 1);
    $ids = $query->execute();
    $vendors = $storage->loadMultiple($ids);
    $version_info = $this->state()->get('custom_vendor_version', ['vendorListVersion' => 1, 'lastUpdated' => (new DrupalDateTime())->format('c')]);
    $result = [
      'vendors' => [],
    ] + $version_info;
    if (!empty($vendors)) {
      foreach ($vendors as $vendor) {
        $item = $vendor->toArray();
        $result['vendors'][] = $this->cleanItem($item);
      }
    }
    $cacheable_metadata = new CacheableMetadata();
    $cacheable_metadata->setCacheTags(['custom_vendor_list']);
    $response = new CacheableJsonResponse($result);
    return $response->addCacheableDependency($cacheable_metadata);
  }

  /**
   * @param $item
   *
   * @return mixed
   */
  private function cleanItem($item) {
    foreach ($item as $key => $value) {
      if (!in_array($key, ['id', 'name', 'policy_url', 'opt_in', 'opt_out', 'purposes', 'features'])) {
        unset($item[$key]);
        continue;
      }
      switch ($key) {
        case 'id':
          $item['id'] = intval($item['id'][0]['value']);
          break;
        case 'name':
          $item['name'] = $item['name'][0]['value'];
          break;
        case 'policy_url':
          $item['policyUrl'] = $item['policy_url'][0]['uri'];
          unset($item['policy_url']);
          break;
        case 'opt_in':
          $item['optInSnippet'] = $item['opt_in'][0]['value'];
          unset($item['opt_in']);
          break;
        case 'opt_out':
          $item['optOutSnippet'] = $item['opt_out'][0]['value'];
          unset($item['opt_out']);
          break;
        case 'purposes':
          $item['purposeIds'] = [];
          foreach ($item['purposes'] as $delta => $target_id) {
            $item['purposeIds'][] = intval($delta + 1);
          };
          unset($item['purposes']);
          break;
        case 'features':
          $item['featureIds'] = [];
          foreach ($item['features'] as $delta => $target_id) {
            $item['featureIds'][] = intval($delta + 1);
          };
          unset($item['features']);
          break;
      }
    }
    return $item;
  }

}
