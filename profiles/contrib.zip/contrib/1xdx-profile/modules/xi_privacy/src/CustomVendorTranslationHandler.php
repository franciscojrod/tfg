<?php

namespace Drupal\xi_privacy;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for custom_vendor.
 */
class CustomVendorTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.
}
