<?php

namespace Drupal\xi_privacy\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\RevisionLogInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\Core\Entity\EntityPublishedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Custom vendor entities.
 *
 * @ingroup xi_privacy
 */
interface CustomVendorInterface extends ContentEntityInterface, RevisionLogInterface, EntityChangedInterface, EntityPublishedInterface, EntityOwnerInterface {

  /**
   * Add get/set methods for your configuration properties here.
   */

  /**
   * Gets the Custom vendor name.
   *
   * @return string
   *   Name of the Custom vendor.
   */
  public function getName();

  /**
   * Sets the Custom vendor name.
   *
   * @param string $name
   *   The Custom vendor name.
   *
   * @return \Drupal\xi_privacy\Entity\CustomVendorInterface
   *   The called Custom vendor entity.
   */
  public function setName($name);

  /**
   * Gets the Custom vendor creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Custom vendor.
   */
  public function getCreatedTime();

  /**
   * Sets the Custom vendor creation timestamp.
   *
   * @param int $timestamp
   *   The Custom vendor creation timestamp.
   *
   * @return \Drupal\xi_privacy\Entity\CustomVendorInterface
   *   The called Custom vendor entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Gets the Custom vendor revision creation timestamp.
   *
   * @return int
   *   The UNIX timestamp of when this revision was created.
   */
  public function getRevisionCreationTime();

  /**
   * Sets the Custom vendor revision creation timestamp.
   *
   * @param int $timestamp
   *   The UNIX timestamp of when this revision was created.
   *
   * @return \Drupal\xi_privacy\Entity\CustomVendorInterface
   *   The called Custom vendor entity.
   */
  public function setRevisionCreationTime($timestamp);

  /**
   * Gets the Custom vendor revision author.
   *
   * @return \Drupal\user\UserInterface
   *   The user entity for the revision author.
   */
  public function getRevisionUser();

  /**
   * Sets the Custom vendor revision author.
   *
   * @param int $uid
   *   The user ID of the revision author.
   *
   * @return \Drupal\xi_privacy\Entity\CustomVendorInterface
   *   The called Custom vendor entity.
   */
  public function setRevisionUserId($uid);

}
