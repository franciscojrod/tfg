<?php

namespace Drupal\xi_privacy\Entity;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EditorialContentEntityBase;
use Drupal\Core\Entity\RevisionableInterface;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityPublishedTrait;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\user\EntityOwnerTrait;

/**
 * Defines the Custom vendor entity.
 *
 * @ingroup xi_privacy
 *
 * @ContentEntityType(
 *   id = "custom_vendor",
 *   label = @Translation("Custom vendor"),
 *   handlers = {
 *     "storage" = "Drupal\xi_privacy\CustomVendorStorage",
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\xi_privacy\CustomVendorListBuilder",
 *     "views_data" = "Drupal\xi_privacy\Entity\CustomVendorViewsData",
 *     "translation" = "Drupal\xi_privacy\CustomVendorTranslationHandler",
 *
 *     "form" = {
 *       "default" = "Drupal\xi_privacy\Form\CustomVendorForm",
 *       "add" = "Drupal\xi_privacy\Form\CustomVendorForm",
 *       "edit" = "Drupal\xi_privacy\Form\CustomVendorForm",
 *       "delete" = "Drupal\xi_privacy\Form\CustomVendorDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\xi_privacy\CustomVendorHtmlRouteProvider",
 *     },
 *     "access" = "Drupal\xi_privacy\CustomVendorAccessControlHandler",
 *   },
 *   base_table = "custom_vendor",
 *   data_table = "custom_vendor_field_data",
 *   revision_table = "custom_vendor_revision",
 *   revision_data_table = "custom_vendor_field_revision",
 *   translatable = TRUE,
 *   admin_permission = "administer custom vendor entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "revision" = "vid",
 *     "label" = "name",
 *     "uuid" = "uuid",
 *     "langcode" = "langcode",
 *     "owner" = "uid",
 *     "published" = "status",
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/custom_vendor/{custom_vendor}",
 *     "add-form" = "/admin/structure/custom_vendor/add",
 *     "edit-form" = "/admin/structure/custom_vendor/{custom_vendor}/edit",
 *     "delete-form" = "/admin/structure/custom_vendor/{custom_vendor}/delete",
 *     "version-history" = "/admin/structure/custom_vendor/{custom_vendor}/revisions",
 *     "revision" = "/admin/structure/custom_vendor/{custom_vendor}/revisions/{custom_vendor_revision}/view",
 *     "revision_revert" = "/admin/structure/custom_vendor/{custom_vendor}/revisions/{custom_vendor_revision}/revert",
 *     "revision_delete" = "/admin/structure/custom_vendor/{custom_vendor}/revisions/{custom_vendor_revision}/delete",
 *     "translation_revert" = "/admin/structure/custom_vendor/{custom_vendor}/revisions/{custom_vendor_revision}/revert/{langcode}",
 *     "collection" = "/admin/structure/custom_vendor",
 *   },
 *   field_ui_base_route = "custom_vendor.settings"
 * )
 */
class CustomVendor extends EditorialContentEntityBase implements CustomVendorInterface {

  use EntityChangedTrait;
  use EntityPublishedTrait;
  use EntityOwnerTrait;

  /**
   * {@inheritdoc}
   */
  protected function urlRouteParameters($rel) {
    $uri_route_parameters = parent::urlRouteParameters($rel);

    if ($rel === 'revision_revert' && $this instanceof RevisionableInterface) {
      $uri_route_parameters[$this->getEntityTypeId() . '_revision'] = $this->getRevisionId();
    }
    elseif ($rel === 'revision_delete' && $this instanceof RevisionableInterface) {
      $uri_route_parameters[$this->getEntityTypeId() . '_revision'] = $this->getRevisionId();
    }

    return $uri_route_parameters;
  }

  /**
   * {@inheritdoc}
   */
  public function preSave(EntityStorageInterface $storage) {
    parent::preSave($storage);

    foreach (array_keys($this->getTranslationLanguages()) as $langcode) {
      $translation = $this->getTranslation($langcode);

      // If no owner has been set explicitly, make the anonymous user the owner.
      if (!$translation->getOwner()) {
        $translation->setOwnerId(0);
      }
    }

    // If no revision author has been set explicitly,
    // make the custom_vendor owner the revision author.
    if (!$this->getRevisionUser()) {
      $this->setRevisionUserId($this->getOwnerId());
    }
  }

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->get('name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setName($name) {
    $this->set('name', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getCreatedTime() {
    return $this->get('created')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setCreatedTime($timestamp) {
    $this->set('created', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    // Add the published field.
    $fields += static::publishedBaseFieldDefinitions($entity_type);
    $fields += static::ownerBaseFieldDefinitions($entity_type);

    $fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setDescription(t('The name of the Custom vendor entity.'))
      ->setRevisionable(TRUE)
      ->setSettings([
        'max_length' => 50,
        'text_processing' => 0,
      ])
      ->setDefaultValue('')
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -4,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRequired(TRUE);

    $fields['policy_url'] = BaseFieldDefinition::create('link')
      ->setLabel(t('Policy url'))
      ->setRequired(TRUE)
      ->setDescription(t('The link to privacy policy page'))
      ->setRevisionable(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'link_default',
      ])
      ->setSettings([
        'link_type' => 17,
        'title' => 0
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['opt_in'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Opt-in snippet'))
      ->setDescription(t('These snippets are evaluated when the user changes consent and on page load.'))
      ->setDisplayOptions('form', [
        'type' => 'text_textarea',
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['opt_out'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Opt-out snippet'))
      ->setDescription(t('These snippets are evaluated when the user changes consent and on page load.'))
      ->setDisplayOptions('form', [
        'type' => 'text_textarea',
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['purposes'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Purposes'))
      ->setDescription(t('The purpose of the vendor to use cookies and tracking'))
      ->setSettings([
        'target_type' => 'taxonomy_term',
        'handler' => 'default',
        'handler_settings' => [
          'target_bundles' => [
            'purpose'
          ]
        ]
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
        'multiple' => TRUE,
      ])
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setDisplayConfigurable('form', TRUE);

    $fields['features'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Features'))
      ->setDescription(t('The features of the vendor'))
      ->setSettings([
        'target_type' => 'taxonomy_term',
        'handler' => 'default',
        'handler_settings' => [
          'target_bundles' => [
            'feature'
          ]
        ]
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
        'multiple' => TRUE,
      ])
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setDisplayConfigurable('form', TRUE);

    $fields['status']->setDescription(t('A boolean indicating whether the Custom vendor is published.'))
      ->setDisplayOptions('form', [
        'type' => 'boolean_checkbox',
        'weight' => -3,
      ]);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'))
      ->setDescription(t('The time that the entity was created.'));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the entity was last edited.'));

    $fields['revision_translation_affected'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Revision translation affected'))
      ->setDescription(t('Indicates if the last edit of a translation belongs to current revision.'))
      ->setReadOnly(TRUE)
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE);

    return $fields;
  }

}
