<?php

namespace Drupal\xi_privacy;

use Drupal\Core\Entity\ContentEntityStorageInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\xi_privacy\Entity\CustomVendorInterface;

/**
 * Defines the storage handler class for Custom vendor entities.
 *
 * This extends the base storage class, adding required special handling for
 * Custom vendor entities.
 *
 * @ingroup xi_privacy
 */
interface CustomVendorStorageInterface extends ContentEntityStorageInterface {

  /**
   * Gets a list of Custom vendor revision IDs for a specific Custom vendor.
   *
   * @param \Drupal\xi_privacy\Entity\CustomVendorInterface $entity
   *   The Custom vendor entity.
   *
   * @return int[]
   *   Custom vendor revision IDs (in ascending order).
   */
  public function revisionIds(CustomVendorInterface $entity);

  /**
   * Gets a list of revision IDs having a given user as Custom vendor author.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user entity.
   *
   * @return int[]
   *   Custom vendor revision IDs (in ascending order).
   */
  public function userRevisionIds(AccountInterface $account);

  /**
   * Counts the number of revisions in the default language.
   *
   * @param \Drupal\xi_privacy\Entity\CustomVendorInterface $entity
   *   The Custom vendor entity.
   *
   * @return int
   *   The number of revisions in the default language.
   */
  public function countDefaultLanguageRevisions(CustomVendorInterface $entity);

  /**
   * Unsets the language for all Custom vendor with the given language.
   *
   * @param \Drupal\Core\Language\LanguageInterface $language
   *   The language object.
   */
  public function clearRevisionsLanguage(LanguageInterface $language);

}
