<?php

namespace Drupal\xi_privacy;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of Custom vendor entities.
 *
 * @ingroup xi_privacy
 */
class CustomVendorListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('Custom vendor ID');
    $header['name'] = $this->t('Name');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var \Drupal\xi_privacy\Entity\CustomVendor $entity */
    $row['id'] = $entity->id();
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.custom_vendor.edit_form',
      ['custom_vendor' => $entity->id()]
    );
    return $row + parent::buildRow($entity);
  }

}
