<?php


namespace Drupal\xi_content_translation\EventSubscriber;


use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Class ResponseSubscriber
 *
 * @package Drupal\xi_content_translation\EventSubscriber
 */
class ResponseSubscriber implements EventSubscriberInterface {

  /**
   * The language manager.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * The currently active route match object.
   *
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  protected $routeMatch;

  /**
   * ContentTranslationRedirectRequestSubscriber constructor.
   *
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   The language manager.
   * @param \Drupal\Core\Routing\RouteMatchInterface $route_match
   *   The currently active route match object.
   */
  public function __construct(LanguageManagerInterface $language_manager, RouteMatchInterface $route_match) {
    $this->languageManager = $language_manager;
    $this->routeMatch = $route_match;
  }

  /**
   * @inheritDoc
   */
  public static function getSubscribedEvents() {
    $events[KernelEvents::RESPONSE][] = ['onResponse'];
    return $events;
  }

  /**
   * @param \Symfony\Component\HttpKernel\Event\FilterResponseEvent $event
   */
  public function onResponse(FilterResponseEvent $event) {
    /** @var \Drupal\Core\Entity\ContentEntityInterface $entity */
    $entity = $this->checkContentEntityCanonicalRoute();
    if ($entity && $this->languageManager->getCurrentLanguage()->getId() !== $entity->language()->getId()) {
      $response = $event->getResponse();
      $response->headers->set('X-Robots-Tag', 'noindex');
      $event->setResponse($response);
    }
  }

  /**
   * Check that the current route is the content entity canonical route.
   *
   * @return \Drupal\Core\Entity\ContentEntityInterface|bool
   *   The entity instance. FALSE if no entity is matched.
   */
  public function checkContentEntityCanonicalRoute() {
    // Get current route name from route match.
    $route_name = $this->routeMatch->getRouteName();
    // If no route is matched.
    if (empty($route_name)) {
      return FALSE;
    }

    // Trying to find the Entity Type ID in the route parameters.
    foreach ($this->routeMatch->getParameters() as $parameter) {
      if ($parameter instanceof ContentEntityInterface) {
        try {
          // Compare entity canonical URL with current URL.
          $entity_route_name = $parameter->toUrl()->getRouteName();
          if ($entity_route_name == $route_name) {
            return $parameter;
          }
        }
        catch (\Exception $e) {
          // There is no canonical URL for this entity,
          // proceed to the next entity.
          continue;
        }
      }
    }
    return FALSE;
  }

}
