<?php

namespace Drupal\xi_elastic;


use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\DependencyInjection\ServiceProviderBase;

/**
 * Class XiElasticServiceProvider.
 *
 * Modifies the normalizer from elasticsearch_helper_content to use proper
 * view modes for indexing.
 *
 * @package Drupal\xi_elastic
 */
class XiElasticServiceProvider extends ServiceProviderBase {

  /**
   * {@inheritdoc}
   */
  public function alter(ContainerBuilder $container) {
    // Overrides elasticsearch_helper_content.normalizer.elasticsearch_content_normalizer class
    // to use other view modes for indexing.
    $definition = $container->getDefinition('elasticsearch_helper_content.normalizer.elasticsearch_content_normalizer');
    $definition->setClass('Drupal\xi_elastic\Plugin\Normalizer\XiContentNormalizer');
  }

}
