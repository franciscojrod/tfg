<?php

namespace Drupal\xi_elastic\Normalizer;


use Drupal\serialization\Normalizer\EntityReferenceFieldItemNormalizer;

/**
 * Class XiTaxonomyTermNormalizer
 *
 * @package Drupal\xi_elastic\Plugin\Normalizer
 */
class XiTaxonomyTermNormalizer extends EntityReferenceFieldItemNormalizer {

  /**
   * @var array
   *   Supported formats.
   */
  protected $format = ['elasticsearch_helper'];

  /**
   * {@inheritdoc}
   */
  public function supportsNormalization($data, $format = NULL) {
    if (parent::supportsNormalization($data, $format)) {
      // Apply the normalizer only to taxonomy term.
      if ($this->fieldItemReferencesTaxonomyTerm($data)) {
        return TRUE;
      }
    }
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function normalize($field_item, $format = NULL, array $context = []) {
    $data = parent::normalize($field_item, $format, $context);
    if (!empty($context['langcode'])) {
      $language = $context['langcode'];
    } else {
      $language = $field_item->getEntity()->language()->getId();
    }
    /** @var \Drupal\Core\Entity\EntityInterface $entity */
    if ($entity = $field_item->get('entity')->getValue()) {
      $label = $entity->label();
      // Add the label of the taxonomy.
      if (method_exists($entity, 'hasTranslation') && $entity->hasTranslation($language)) {
        $label = $entity->getTranslation($language)->label();
      }
      $data['label'] = $label;
    }
    return $data;
  }

}
