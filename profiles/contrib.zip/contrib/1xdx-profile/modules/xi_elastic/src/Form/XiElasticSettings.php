<?php


namespace Drupal\xi_elastic\Form;


use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class XiElasticSettings
 *
 * @package Drupal\xi_elastic\Form
 */
class XiElasticSettings extends ConfigFormBase {

  /**
   * @var \Drupal\elasticsearch_helper\Plugin\ElasticsearchIndexManager
   */
  protected $pluginManager;

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * @var \Drupal\Core\Entity\EntityTypeBundleInfoInterface
   */
  protected $entityTypeBundleInfo;

  /**
   * @var array
   */
  protected $plugins;

  /**
   * @var \Drupal\Core\Cache\CacheBackendInterface
   */
  protected $cacheBackend;

  /**
   * @var \Drupal\Core\State\StateInterface
   */
  protected $state;

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->pluginManager = $container->get('plugin.manager.elasticsearch_index.processor');
    $instance->entityTypeManager = $container->get('entity_type.manager');
    $instance->entityTypeBundleInfo = $container->get('entity_type.bundle.info');
    $instance->state = $container->get('state');
    $instance->plugins = $instance->state->get('xi_elastic.indexes');
    $instance->cacheBackend = $container->get('cache.discovery');
    return $instance;
  }

  /**
   * @inheritDoc
   */
  protected function getEditableConfigNames() {
    return ['xi_elastic.settings'];
  }

  /**
   * @inheritDoc
   */
  public function getFormId() {
    return 'xi_elastic_settings';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('xi_elastic.settings');

    // Visibility settings.
    $form['settings'] = [
      '#type' => 'vertical_tabs',
      '#title' => $this->t('Settings'),
    ];

    $form['general'] = [
      '#type' => 'details',
      '#title' => $this->t('General settings'),
      '#group' => 'settings',
    ];

    $form['general']['prefix'] = [
      '#default_value' => $config->get('prefix'),
      '#description' => $this->t('Search Index Prefix to distinguish the indexes within the cluster'),
      '#maxlength' => 20,
      '#required' => TRUE,
      '#size' => 15,
      '#title' => $this->t('Index Prefix'),
      '#type' => 'textfield',
    ];

    $options = [];
    foreach ($this->plugins as $plugin) {
      $options[$plugin['id']] = $plugin['label'];
    }
    $enabled_indexes = $config->get('indexes') ? $config->get('indexes') : [];
    $form['general']['indexes'] = [
      '#default_value' => $enabled_indexes,
      '#description' => $this->t('You can enable or disable indexes'),
      '#title' => $this->t('Enabled indexes'),
      '#type' => 'checkboxes',
      '#options' => $options,
    ];

    $form['index_data'] = [
      '#type' => 'details',
      '#title' => $this->t('Index settings'),
      '#group' => 'settings',
    ];
    $form['index_data']['index_view_mode'] = [
      '#tree' => TRUE,
      '#type' => 'details',
      '#open' => TRUE,
      '#title' => $this->t('Index view mode'),
    ];
    $form['index_data']['display_view_mode'] = [
      '#tree' => TRUE,
      '#type' => 'details',
      '#open' => TRUE,
      '#title' => $this->t('Display view mode'),
    ];
    $index_view_mode = $config->get('index_view_mode');
    $display_view_mode = $config->get('display_view_mode');
    foreach ($this->plugins as $plugin) {
      $options[$plugin['id']] = $plugin['label'];
      if (!empty($enabled_indexes[$plugin['id']])) {
        $view_modes = $this->entityTypeManager->getStorage('entity_view_mode')->loadByProperties(['targetEntityType' => $plugin['entityType']]);
        $view_mode_options = ['' => $this->t('-- Choose view mode --')];
        foreach ($view_modes as $view_mode) {
          $view_mode_options[$view_mode->id()] = $view_mode->label();
        }
        $form['index_data']['index_view_mode'][$plugin['entityType']] = [
          '#type' => 'select',
          '#options' => $view_mode_options,
          '#title' => $plugin['label'],
          '#default_value' => !empty($index_view_mode[$plugin['entityType']]) ? $index_view_mode[$plugin['entityType']] : '',
        ];
        $form['index_data']['display_view_mode'][$plugin['entityType']] = [
          '#type' => 'select',
          '#options' => $view_mode_options,
          '#title' => $plugin['label'],
          '#default_value' => !empty($display_view_mode[$plugin['entityType']]) ? $display_view_mode[$plugin['entityType']] : '',
        ];
      }
    }
    $exclude = $config->get('exclude');
    $form['exclude_options'] = [
      '#type' => 'details',
      '#title' => $this->t('Bundles to exclude'),
      '#group' => 'settings',
    ];
    $form['exclude_options']['exclude'] = [
      '#tree' => TRUE,
      '#type' => 'container',
    ];
    foreach ($this->plugins as $plugin) {
      $options[$plugin['id']] = $plugin['label'];
      if (!empty($enabled_indexes[$plugin['id']])) {
        $bundle_options = [];
        $bundles = $this->entityTypeBundleInfo->getBundleInfo($plugin['entityType']);
        foreach ($bundles as $bundle_name => $bundle) {
          $bundle_options[$bundle_name] = $bundle['label'];
        }
        $form['exclude_options']['exclude'][$plugin['entityType']] = [
          '#type' => 'checkboxes',
          '#options' => $bundle_options,
          '#title' => $plugin['label'],
          '#default_value' => !empty($exclude[$plugin['entityType']]) ? $exclude[$plugin['entityType']] : [],
        ];
      }
    }
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $config = $this->config('xi_elastic.settings');
    $old_indexes = $config->get('indexes');
    $indexes = $form_state->getValue('indexes');
    $config
      ->set('prefix', $form_state->getValue('prefix'))
      ->set('indexes', $indexes)
      ->set('index_view_mode', $form_state->getValue('index_view_mode'))
      ->set('display_view_mode', $form_state->getValue('display_view_mode'))
      ->set('exclude', $form_state->getValue('exclude'))
      ->save();
    $this->state->set('xi_elastic.update_indexes', TRUE);
    $this->cacheBackend->delete('elasticsearch_helper_elasticsearch_index_plugins');
    foreach ($indexes as $key => $index) {
      $pluginInstance = $this->pluginManager->createInstance($key);
      if (!$index && $old_indexes[$key]) {
        $pluginInstance->drop();
      }
      elseif (!$old_indexes[$key] && $index) {
        $pluginInstance->setup();
      }
    }
    $this->state->set('xi_elastic.update_indexes', FALSE);
    $this->cacheBackend->delete('elasticsearch_helper_elasticsearch_index_plugins');
    $this->pluginManager->reindex();
    parent::submitForm($form, $form_state);
  }

}
