# Reactive search block

## Installation

Install module as usual. The dependencies will be installed automatically. 
Make sure file js/build/search/main.js exists. If it doesn't:
- navigate to js/build/search folder 
- run `npm install`
- run `npm run build`
- clear the caches


## Configuration

First you need to follow the setup procedure of the elasticsearch_helper module.
Use drush commands to setup index, set the content for indexing and run cron.

The module provides the block that you can place in any region. The block has 
settings that needs to be configured prior usage:
- the url of the elastic server REST endpoint
- the name of the index 
- the CSS selector of the element that will be substituted with Highlights (excerpt) from 
elastic search result (optional).


### How to get the name of the index?

As the name of the index has prefix it is not possible to know the id of it on elastic before
something was indexed. After you index at least one entity go to http://elastic.1xinternet.de/_search
and check the _index property of search results. The id should be in this format:
`{prefix}-content-node-{langcode}` . {prefix} part is added automatically and depends on site salt,
so it is completely unpredictable to get it in advance. This is made so the cluster could be used
for multiple websites.

### What is actually being indexed?

Please read first documentation of elasticsearch_helper_content module. 
By default all the fields of entity are indexed and also 2 special fields are there added by index plugin:
- full view mode of the entity
- teaser view mode of the entity (used for displaying the search results)

### Where to get CSS selector for 3rd setting in the block?

As search results display teaser mode of the entity, to get the highlights inside the results
one need to inject them into DOM of the result HTML structure. For this the selector is needed.
Just inspect in the browser and find the css selector of the HTML element that should contain the 
highlights content.


### Local Development - Elastic + Traefik

When using a local setup (elastic + docker) you might need one addtional url to get xi_elastic search blocks work.

If elastic is reachable from outside docker container through port 80 this is not needed.

#### 1. in local settings.php 


```
   #backend
   $config['elasticsearch_helper.settings']['elasticsearch_helper']['host'] = 'elasticsearch';
   $config['elasticsearch_helper.settings']['elasticsearch_helper']['port'] = '9200';
   
   #frontend
   $config['elasticsearch_helper.settings']['elasticsearch_helper']['api_uri'] = '<enter local domain here>';
   ...
``` 

'api_url' will be used in Drupal\xi_elastic\Plugin\Block\SearchIndexBlock.php (s. line 63) if available.

#### 2. add traefik behaviour in docker-compose 

```
  elasticsearch:
    image: wodby/elasticsearch:$ELASTICSEARCH_TAG
    container_name: "${PROJECT_NAME}_elastic"
    environment:
      ES_JAVA_OPTS: "-Xms500m -Xmx500m"
    ulimits:
      memlock:
        soft: -1
        hard: -1
    labels:
      - 'traefik.backend=elasticsearch'
      - 'traefik.port=9200'
      - 'traefik.frontend.rule=Host:<enter local domain here >'
```



#### 3. If you will use the online server, check hash

In settings.php, settings.local.php and settings.ddev.php

```
    $settings['hash_salt'] = 'the same as in test server or the server that you want to synchronize';
```
