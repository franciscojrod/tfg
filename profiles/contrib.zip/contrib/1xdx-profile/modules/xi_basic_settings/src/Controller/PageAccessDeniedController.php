<?php

namespace Drupal\xi_basic_settings\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class PageAccessDeniedController.
 */
class PageAccessDeniedController extends ControllerBase {

  /**
   * Return content for the 403 page.
   *
   * @return string
   *   Return 403 string.
   */
  public function content() {
    return ['#theme' => 'page_access_denied'];
  }

}
