<?php

namespace Drupal\xi_basic_settings\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class PageNotFoundController.
 */
class PageNotFoundController extends ControllerBase {

  /**
   * Return content for the 404 page.
   *
   * @return string
   *   Return 404 string.
   */
  public function content() {
    return ['#theme' => 'page_not_found'];
  }

}
