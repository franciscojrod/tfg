<?php

namespace Drupal\xi_teaser_entity\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Teaser entities.
 *
 * @ingroup xi_teaser_entity
 */
interface TeaserEntityInterface extends ContentEntityInterface, EntityChangedInterface, EntityOwnerInterface {

  // Add get/set methods for your configuration properties here.

  /**
   * Gets the Teaser name.
   *
   * @return string
   *   Name of the Teaser.
   */
  public function getName();

  /**
   * Sets the Teaser name.
   *
   * @param string $name
   *   The Teaser name.
   *
   * @return \Drupal\xi_teaser_entity\Entity\TeaserEntityInterface
   *   The called Teaser entity.
   */
  public function setName($name);

  /**
   * Gets the Teaser creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Teaser.
   */
  public function getCreatedTime();

  /**
   * Sets the Teaser creation timestamp.
   *
   * @param int $timestamp
   *   The Teaser creation timestamp.
   *
   * @return \Drupal\xi_teaser_entity\Entity\TeaserEntityInterface
   *   The called Teaser entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Returns the Teaser published status indicator.
   *
   * Unpublished Teaser are only visible to restricted users.
   *
   * @return bool
   *   TRUE if the Teaser is published.
   */
  public function isPublished();

  /**
   * Sets the published status of a Teaser.
   *
   * @param bool $published
   *   TRUE to set this Teaser to published, FALSE to set it to unpublished.
   *
   * @return \Drupal\xi_teaser_entity\Entity\TeaserEntityInterface
   *   The called Teaser entity.
   */
  public function setPublished($published);

}
