<?php

namespace Drupal\xi_teaser_entity\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Teaser entities.
 *
 * @ingroup xi_teaser_entity
 */
class TeaserEntityDeleteForm extends ContentEntityDeleteForm {


}
