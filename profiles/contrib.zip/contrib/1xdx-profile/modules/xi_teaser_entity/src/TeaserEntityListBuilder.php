<?php

namespace Drupal\xi_teaser_entity;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of Teaser entities.
 *
 * @ingroup xi_teaser_entity
 */
class TeaserEntityListBuilder extends EntityListBuilder {


  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['name'] = $this->t('Title');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\xi_teaser_entity\Entity\TeaserEntity */
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.teaser_entity.edit_form',
      ['teaser_entity' => $entity->id()]
    );
    return $row + parent::buildRow($entity);
  }

}
