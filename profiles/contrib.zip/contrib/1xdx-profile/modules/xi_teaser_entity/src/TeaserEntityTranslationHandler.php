<?php

namespace Drupal\xi_teaser_entity;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for teaser_entity.
 */
class TeaserEntityTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.

}
