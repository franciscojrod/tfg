<?php

namespace Drupal\xi_teaser_entity;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the Teaser entity.
 *
 * @see \Drupal\xi_teaser_entity\Entity\TeaserEntity.
 */
class TeaserEntityAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\xi_teaser_entity\Entity\TeaserEntityInterface $entity */
    switch ($operation) {
      case 'view':
        if (!$entity->isPublished()) {
          return AccessResult::allowedIfHasPermission($account, 'view unpublished teaser entities');
        }
        return AccessResult::allowedIfHasPermission($account, 'view published teaser entities');

      case 'update':
        return AccessResult::allowedIfHasPermission($account, 'edit teaser entities');

      case 'delete':
        return AccessResult::allowedIfHasPermission($account, 'delete teaser entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add teaser entities');
  }

}
