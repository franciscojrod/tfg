<?php

namespace Drupal\xi_demo\EventSubscriber;


use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\default_content\Event\DefaultContentEvents;
use Drupal\default_content\Event\ImportEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Class DefaultContentListener
 *
 * @package Drupal\xi_demo\EventSubscriber
 */
class DefaultContentListener implements EventSubscriberInterface {

  /**
   * @var \Drupal\Core\Config\ImmutableConfig
   */
  protected $config;

  /**
   * DefaultContentListener constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   */
  public function __construct(ConfigFactoryInterface $configFactory) {
    $this->config = $configFactory->getEditable('system.site');
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    return [
      DefaultContentEvents::IMPORT => 'onContentImport',
    ];
  }

  /**
   * React on content import event.
   *
   * @param \Drupal\default_content\Event\ImportEvent $event
   */
  public function onContentImport(ImportEvent $event) {
    $module = $event->getModule();
    if ($module == 'xi_demo') {
      $imported_entities = $event->getImportedEntities();
      foreach ($imported_entities as $entity) {
        if ($entity->getEntityTypeId() == 'node' && $entity->bundle() == 'page' && $entity->label() == 'Frontpage') {
          $pages = $this->config->get('page');
          $pages['front'] = '/node/' . $entity->id();
          $this->config->set('page', $pages);
          $this->config->save(TRUE);
        }
      }
    }
  }

}
