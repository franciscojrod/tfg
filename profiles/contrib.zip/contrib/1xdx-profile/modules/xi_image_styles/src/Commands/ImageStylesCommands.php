<?php

namespace Drupal\xi_image_styles\Commands;

use Drupal\Component\Uuid\UuidInterface;
use Drupal\Core\Config\StorageInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Logger\LoggerChannelFactory;
use Drupal\image\Entity\ImageStyle;
use Drupal\responsive_image\Entity\ResponsiveImageStyle;
use Drush\Commands\DrushCommands;
use Exception;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;
use Symfony\Component\Yaml\Yaml;

/**
 * A Drush commandfile.
 *
 * In addition to this file, you need a drush.services.yml
 * in root of your module, and a composer.json file that provides the name
 * of the services file to use.
 *
 * See these files for an example of injecting Drupal services:
 *   - http://cgit.drupalcode.org/devel/tree/src/Commands/DevelCommands.php
 *   - http://cgit.drupalcode.org/devel/tree/drush.services.yml
 */
class ImageStylesCommands extends DrushCommands {

  /**
   *  File name with template configuration for image style.
   */
  const IMAGE_STYLE_TEMPLATE = 'image.style.machine_name.yml';

  /**
   *  File name with template configuration for responsive image style.
   */
  const RESPONSIVE_IMAGE_STYLE_TEMPLATE = 'responsive_image.styles.name.yml';

  /**
   *  File name with template configuration for media image display.
   */
  const MEDIA_IMAGE_DISPLAY_TEMPLATE = 'core.entity_view_display.media.image.display.yml';

  /**
   *  File name with template configuration for media image view mode.
   */
  const MEDIA_IMAGE_VIEW_MODE_TEMPLATE = 'core.entity_view_mode.media.display.yml';

  /**
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleHandler;

  /**
   * @var array
   */
  protected $defaultWidths = ['480', '768', '1024', '1440'];

  /**
   * @var
   */
  protected $options;

  /**
   * @var
   */
  protected $styleMachineName;

  /**
   * A logger instance.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * A logger instance.
   *
   * @var \Drupal\Component\Uuid\UuidInterface
   */
  protected $uuidGenerator;

  /**
   * The config storage service.
   *
   * @var \Drupal\Core\Config\StorageInterface
   */
  protected $baseStorage;

  /**
   * ImageStylesCommands constructor.
   *
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   * @param LoggerChannelFactory $logger_factory
   * @param UuidInterface $uuid_generator
   * @param StorageInterface $storage
   */
  public function __construct(ModuleHandlerInterface $module_handler, LoggerChannelFactory $logger_factory, UuidInterface $uuid_generator, StorageInterface $storage) {
    parent::__construct();
    $this->moduleHandler = $module_handler;
    $this->uuidGenerator = $uuid_generator;
    $this->logger = $logger_factory->get('xi_image_styles');
    $this->baseStorage = $storage;
  }

  /**
   * Generates images style.
   *
   * @param array $options An associative array of options whose values come
   *   from cli, aliases, config, etc.
   *
   * @usage drush generate-image-style
   *   Generates images style.
   *
   * @command generate-image-style
   * @aliases geis,generate-image-style
   *
   * Examples:
   *  - drush geis --name Banner --ratio 6:1
   */
  public function generateImagesStyle(array $options = ['name' => NULL, 'ratio' => NULL, 'responsive' => TRUE, 'display' => TRUE]) {
    // Validate input data.
    if (empty($options['name'])) {
      $this->writeLog(t('The --name argument required.'));
      return FALSE;
    }
    if (empty($options['ratio'])) {
      $this->writeLog(t('The --ratio argument required. Example: 6:1.'));
      return FALSE;
    }
    // Creating & importing configuration.
    try {
      $this->options = $options;
      $this->styleMachineName = preg_replace('@[^a-z0-9]+@','_', strtolower($options['name']));
      // Generate image styles configuration files.
      $this->writeLog(t('Generating configuration...'));
      $this->generateConfiguration();
      // Import generate configuration.
      $this->writeLog(t('Importing configuration...'));
      $this->importConfiguration();
      // Delete generated files.
      $this->writeLog(t('Deleting temporary files...'));
      $path = rtrim($this->getStylesPath(), '/');
      if (is_dir($path)) {
        $dir = dir($path);
        while (($entry = $dir->read()) !== FALSE) {
          if ($entry == '.' || $entry == '..' || ! preg_match('%\W(yml)$%i', $entry)) {
            continue;
          }
          $entry_path = $path . '/' . $entry;
          file_unmanaged_delete($entry_path);
        }
        $dir->close();
      }
      $this->writeLog(t('Done.'));
    }
    catch (Exception $e) {
      $this->writeLog($e->getMessage(), TRUE);
    }
  }

  /**
   * @param $msg
   * @param bool $system
   */
  private function writeLog($msg, $system = FALSE) {
    drush_print($msg);
    if ($system) {
      $this->logger->info($msg);
    }
  }

  /**
   * Generate configuration files.
   */
  protected function generateConfiguration() {
    $image_style_names = $this->generateImageStylesConfiguration();
    if (!empty($image_style_names)) {
      $this->writeLog(t('- Created configuration for image styles: @styles', ['@styles' => implode(',', array_keys($image_style_names))]));
      if ($this->options['responsive']) {
        $this->generateResponsiveImageStyleConfiguration($image_style_names);
      }
      if ($this->options['display']) {
        $this->generateMediaImageDisplayConfiguration();
      }
    }
  }

  /**
   * Generate responsive image style configuration file.
   *
   * @return array
   */
  private function generateImageStylesConfiguration() {
    $sizes = $this->calculateImageSizes($this->options['ratio']);
    $image_style_names = [];
    foreach ($sizes as $size) {
      $style_machine_name = $this->styleMachineName . '_' . $size['machine_name'];
      // Check if machine name already exist.
      $image_style = ImageStyle::load($style_machine_name);
      if (!empty($image_style)) {
        $this->writeLog(t('Image style with machine name @name already exist', ['@name' => $style_machine_name]));
        continue;
      }
      $tpl = Yaml::parseFile($this->getTemplatesPath() . self::IMAGE_STYLE_TEMPLATE);
      $tpl['name'] = $style_machine_name;
      $tpl['label'] = $this->options['name'] . ' ' . $size['width'];
      $effect_uuid = $this->uuidGenerator->generate();
      $tpl['effects'][$effect_uuid]['uuid'] = $effect_uuid;
      $tpl['effects'][$effect_uuid]['id'] = 'focal_point_scale_and_crop';
      $tpl['effects'][$effect_uuid]['weight'] = 1;
      $tpl['effects'][$effect_uuid]['data']['width'] = (int) $size['width'];
      $tpl['effects'][$effect_uuid]['data']['height'] = (int) $size['height'];
      $tpl['effects'][$effect_uuid]['data']['crop_type'] = 'focal_point';
      file_put_contents($this->getStylesPath() . str_replace('machine_name', $style_machine_name,self::IMAGE_STYLE_TEMPLATE), Yaml::dump($tpl, 10, 2));
      $image_style_names[$style_machine_name] = $size;
    }
    return $image_style_names;
  }

  /**
   * Generate media image view display configuration file.
   *
   * @param $image_style_names
   */
  private function generateResponsiveImageStyleConfiguration($image_style_names) {
    // Check is responsive image style already exist.
    $responsive_image_style = ResponsiveImageStyle::load($this->styleMachineName);
    if (!empty($responsive_image_style)) {
      $this->writeLog(t('Responsive image style with machine name @name already exist', ['@name' => $this->styleMachineName]));
      return;
    }
    $tpl = Yaml::parseFile($this->getTemplatesPath() . self::RESPONSIVE_IMAGE_STYLE_TEMPLATE);
    $tpl['id'] = $this->styleMachineName;
    $tpl['label'] = $this->options['name'];
    $tpl['dependencies']['config'] = [];
    foreach ($image_style_names as $image_style_name => $size) {
      $tpl['dependencies']['config'][] = 'image.style.' . $image_style_name;
    }
    foreach ($tpl['image_style_mappings'] as $key => $image_style_mapping) {
      $tpl['image_style_mappings'][$key]['image_mapping'] = str_replace('photo_', $this->styleMachineName . '_', $image_style_mapping['image_mapping']);
    }
    $tpl['fallback_image_style'] = array_shift(array_keys($image_style_names));
    file_put_contents($this->getStylesPath() . str_replace('name', $this->styleMachineName,self::RESPONSIVE_IMAGE_STYLE_TEMPLATE), Yaml::dump($tpl, 10, 2));
  }

  /**
   *  Generate media image view display configuration file.
   */
  private function generateMediaImageDisplayConfiguration() {
    // Check is media image display already exist.
    $entity_view_mode_config = $this->baseStorage->read('core.entity_view_display.media.image.' . $this->styleMachineName);
    if (!empty($entity_view_mode_config)) {
      $this->writeLog(t('Entity view mode for image style @name already exist', ['@name' => $this->styleMachineName]));
      return;
    }
    // Generate core.entity_view_mode.media.{{name}.yml
    $tpl = Yaml::parseFile($this->getTemplatesPath() . self::MEDIA_IMAGE_VIEW_MODE_TEMPLATE);
    $tpl['id'] = 'media.' . $this->styleMachineName;
    $tpl['label'] = $this->options['name'];
    file_put_contents($this->getStylesPath() . str_replace('display', $this->styleMachineName,self::MEDIA_IMAGE_VIEW_MODE_TEMPLATE), Yaml::dump($tpl, 10, 2));
    // Generate core.entity_view_display.media.image.{{name}}.yml
    $tpl = Yaml::parseFile($this->getTemplatesPath() . self::MEDIA_IMAGE_DISPLAY_TEMPLATE);
    $tpl['id'] = 'media.image.' . $this->styleMachineName;
    $tpl['mode'] = $this->styleMachineName;
    $tpl['content']['field_media_image']['settings']['responsive_image_style'] = $this->styleMachineName;
    foreach ($tpl['dependencies']['config'] as $key => $value) {
      $tpl['dependencies']['config'][$key] = str_replace('photo', $this->styleMachineName, $value);
    }
    file_put_contents($this->getStylesPath() . str_replace('image.display', 'image.'.$this->styleMachineName,self::MEDIA_IMAGE_DISPLAY_TEMPLATE), Yaml::dump($tpl, 10, 2));
  }

  /**
   *  Import image styles configuration.
   */
  private function importConfiguration() {

    $process = new Process('drush cim --partial --source=' . $this->getStylesPath());
    $process->run();

    // Executes after the command finishes.
    if (!$process->isSuccessful()) {
      throw new ProcessFailedException($process);
    }

    echo $process->getOutput();
  }

  /**
   * @return string
   */
  private function getStylesPath() {
    return $this->moduleHandler->getModule('xi_image_styles')->getPath() . '/config/styles/';
  }

  /**
   * @return string
   */
  private function getTemplatesPath() {
    return $this->moduleHandler->getModule('xi_image_styles')->getPath() . '/config/templates/';
  }

  /**
   * Default image style sizes.
   *
   * @param string $ratio
   * @param array $widths
   *
   * @return array
   */
  protected function calculateImageSizes($ratio = '', $widths = []) {
    if (empty($ratio)) {
      return [];
    }
    $sizes = [];
    $widths = array_merge($widths, $this->defaultWidths);
    list($ratio_w, $ratio_h) = explode(':', $ratio);

    foreach ($widths as $width) {
      $sizes[] = [
        'machine_name' => $this->getWidthMachineName($width),
        'width' => $width,
        'height' => ceil(($width/$ratio_w) * $ratio_h)
      ];
    }

    return $sizes;
  }

  /**
   * @param $width
   *
   * @return mixed
   */
  private function getWidthMachineName($width) {
    $names = [
      '480' => 'small',
      '768' => 'medium',
      '1024' => 'large',
      '1440' => 'extra_large',
      '1920' => 'full',
      '3840' => '4k'
    ];
    return isset($names[$width]) ? $names[$width] : $width;
  }
}
