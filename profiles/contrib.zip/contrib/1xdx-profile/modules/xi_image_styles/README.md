# XI Image Styles module

This module won't do much by itself. It provides drush command `generate-image-style` to automatically generate image styles and media entity displays for these styles:

For example command `drush geis --name 'Teaser 5:2' --ratio 5:2` will generate responsive image style named `Teaser 5:2` with image style configurations for 480, 768, 1024 and 1440 px. and create the according display named `Teaser 5:2` for Media type image with focal point as cropping tool.

Here is a list of generated configuration files:                                                                                                                                                                                                                          
  - image.style.teaser_5_2_small.yml
  - image.style.teaser_5_2_medium.yml
  - image.style.teaser_5_2_large.yml
  - image.style.teaser_5_2_extra_large.yml
  - responsive_image.styles.teaser_5_2.yml
  - core.entity_view_mode.media.teaser_5_2.yml
  - core.entity_view_display.media.image.teaser_5_2.yml
