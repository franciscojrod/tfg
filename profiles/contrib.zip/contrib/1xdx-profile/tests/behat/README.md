# Documentation

- Main Page: http://docs.behat.org/en/v2.5/
- Writing Features in Gherkin: http://docs.behat.org/en/v2.5/guides/1.gherkin.html
- Step Definitions: http://docs.behat.org/en/v2.5/guides/2.definitions.html
- Behat Command Line: http://docs.behat.org/en/v2.5/guides/6.cli.html

## Profile testing

<pre>
# Run all tests
./vendor/bin/behat -c web/profiles/custom/xi_profile/tests/behat/behat.yml

# Run all tests on the test environment
export BEHAT_PARAMS='{"extensions":{"Behat\\MinkExtension":{"base_url":"https://test.1xdx.com/"}}}'
./vendor/bin/behat -c web/profiles/custom/xi_profile/tests/behat/behat.yml

# Run all paragraph tests on the local environment
./vendor/bin/behat -c web/profiles/custom/xi_profile/tests/behat/behat.yml --tags="@paragraphs" --profile=local
</pre>

## Notes

> $ behat --story-syntax
>
> This command will print an example feature for you to understand what keywords to use and where to use them in your feature files

> $ behat -dl
>
> This command will print all available definition regular expressions
