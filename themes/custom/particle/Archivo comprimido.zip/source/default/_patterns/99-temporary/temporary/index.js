/**
 * Quick fixes
 *
 * Deadlines happen, so put your quick fixes here. Hopefully there will be time
 * later to move/re-factor these styles into their proper place.
 */

// Module template
import './_temporary.scss';
