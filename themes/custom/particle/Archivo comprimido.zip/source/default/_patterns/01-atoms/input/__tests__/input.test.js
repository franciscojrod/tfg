import { name } from '..';

test('input component is registered', () => {
  expect(name).toBe('input');
});
