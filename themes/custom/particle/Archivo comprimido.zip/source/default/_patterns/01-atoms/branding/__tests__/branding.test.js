import { name } from '..';

test('branding component is registered', () => {
  expect(name).toBe('branding');
});
