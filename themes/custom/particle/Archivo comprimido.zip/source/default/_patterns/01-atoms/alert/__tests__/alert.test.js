import { name } from '..';

test('alert component is registered', () => {
  expect(name).toBe('alert');
});
