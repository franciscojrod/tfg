import { name } from '..';

test('breadcrumb component is registered', () => {
  expect(name).toBe('breadcrumb');
});
