import { name } from '..';

test('badge component is registered', () => {
  expect(name).toBe('badge');
});
