import { name } from '..';

test('image component is registered', () => {
  expect(name).toBe('image');
});
