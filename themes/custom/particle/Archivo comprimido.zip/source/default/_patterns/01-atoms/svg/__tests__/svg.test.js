import { name } from '../index';

test('svg component is registered', () => {
  expect(name).toBe('svg');
});
