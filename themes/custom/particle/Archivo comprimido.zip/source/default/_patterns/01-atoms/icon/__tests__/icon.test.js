import { name } from '..';

test('icon component is registered', () => {
  expect(name).toBe('icon');
});
