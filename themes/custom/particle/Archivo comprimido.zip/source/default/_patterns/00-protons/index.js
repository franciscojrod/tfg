/**
 * Base css generation and global js logic.
 */

import 'tokens/sass/tokens.scss';

// Export global variables.
export default {
  // Demo only, remove in practice
  GLOBAL_CONSTANT: 'particle',
};
