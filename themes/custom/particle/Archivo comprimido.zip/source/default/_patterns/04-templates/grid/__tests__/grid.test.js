import { name } from '..';

test('grid component is registered', () => {
  expect(name).toBe('grid');
});
