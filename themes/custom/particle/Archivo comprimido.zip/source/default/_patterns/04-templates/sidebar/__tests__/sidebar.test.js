import { name } from '..';

test('sidebar component is registered', () => {
  expect(name).toBe('sidebar');
});
