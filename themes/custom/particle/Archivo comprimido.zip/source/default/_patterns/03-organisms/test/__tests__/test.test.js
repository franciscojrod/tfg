import { name } from '..';

test('test component is registered', () => {
  expect(name).toBe('test');
});
