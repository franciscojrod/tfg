import { name } from '..';

test('overlay component is registered', () => {
  expect(name).toBe('overlay');
});
