import { name } from '..';

test('cookie-compliance component is registered', () => {
  expect(name).toBe('cookie-compliance');
});
