import { name } from '..';

test('section component is registered', () => {
  expect(name).toBe('section');
});
