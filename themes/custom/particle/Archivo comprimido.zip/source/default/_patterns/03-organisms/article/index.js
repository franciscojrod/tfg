/**
 * Article
 */

// Module dependencies
import 'protons';

// Module template
import './_article.twig';

// Module styles
import './_article.scss';

export const name = 'article';

export function disable() {}

export function enable() {}

export default enable;
