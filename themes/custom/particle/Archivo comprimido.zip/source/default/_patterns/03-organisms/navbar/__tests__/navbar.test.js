import { name } from '..';

test('navbar component is registered', () => {
  expect(name).toBe('navbar');
});
