import { name } from '..';

test('block component is registered', () => {
  expect(name).toBe('block');
});
