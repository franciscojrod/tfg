import { name } from '..';

test('menu component is registered', () => {
  expect(name).toBe('menu');
});
