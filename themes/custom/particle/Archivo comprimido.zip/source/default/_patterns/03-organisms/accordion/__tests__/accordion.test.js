import { name } from '..';

test('accordion component is registered', () => {
  expect(name).toBe('accordion');
});
