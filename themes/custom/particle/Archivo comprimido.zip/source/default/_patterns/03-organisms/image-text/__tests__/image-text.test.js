import { name } from '..';

test('image-text component is registered', () => {
  expect(name).toBe('image-text');
});
