/**
 * footer
 */

// Module dependencies
import 'protons';

// Module template
import './_footer.twig';

// Module styles
import './_footer.scss';

export const name = 'footer';

export function disable() {}

export function enable() {}

export default enable;
