import { name } from '..';

test('article component is registered', () => {
  expect(name).toBe('article');
});
