import { name } from '..';

test('text component is registered', () => {
  expect(name).toBe('text');
});
