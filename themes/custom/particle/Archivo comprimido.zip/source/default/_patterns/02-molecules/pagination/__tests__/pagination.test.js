import { name } from '..';

test('pagination component is registered', () => {
  expect(name).toBe('pagination');
});
