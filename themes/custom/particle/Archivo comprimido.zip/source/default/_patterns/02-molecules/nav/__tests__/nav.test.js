import { name } from '..';

test('nav component is registered', () => {
  expect(name).toBe('nav');
});
