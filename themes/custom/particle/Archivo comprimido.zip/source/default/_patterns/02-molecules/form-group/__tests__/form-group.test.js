import { name } from '..';

test('form-group component is registered', () => {
  expect(name).toBe('form-group');
});
