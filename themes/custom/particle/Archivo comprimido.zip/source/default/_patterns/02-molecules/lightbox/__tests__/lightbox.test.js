import { name } from '..';

test('lightbox component is registered', () => {
  expect(name).toBe('lightbox');
});
