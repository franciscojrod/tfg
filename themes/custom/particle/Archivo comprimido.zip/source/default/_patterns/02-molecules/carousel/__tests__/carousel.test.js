import { name } from '..';

test('carousel component is registered', () => {
  expect(name).toBe('carousel');
});
