import { name } from '..';

test('card component is registered', () => {
  expect(name).toBe('card');
});
