import { name } from '..';

test('newsletter-signup component is registered', () => {
  expect(name).toBe('newsletter-signup');
});
