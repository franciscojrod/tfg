// const helpers = require('yeoman-test');
// const { join } = require('path');
//
// test('sanity check', () => {
//   expect(1).toEqual(1);
// });
//
// Currently not compatible with yeoman-generator@^4.1.0
// it('generates a project', () => {
//   return helpers
//     .run(join(__dirname, '../generators/app'))
//     .withPrompts({
//       chooseApp: 'app-node-pl',
//       patternType: '02-molecules',
//       name: 'New Component Test',
//     })
//     .then(() => {
//       console.log('Generator ran');
//     });
// });
