# Contributing

Before contributing, please ensure your IDE or text editor is using the `.editorconfig` at the root of this project. To achieve this easily, see the docs section titled ["IDE/text editor setup"](https://phase2.gitbook.io/frontend/particle/development/coding-and-linting#ide-text-editor-setup)

Then to contribute to these tools, just fork this repo, modify as you see fit and push up a pull request!
