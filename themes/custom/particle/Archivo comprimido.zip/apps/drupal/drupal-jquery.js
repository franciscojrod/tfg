import $ from 'jquery/dist/jquery.min';

window.jQuery = $;
