const BUILD_TARGET = 'pl';

test('Pattern Lab requires global BUILD_TARGET of `pl`', () => {
  expect(BUILD_TARGET).toBe('pl');
});
