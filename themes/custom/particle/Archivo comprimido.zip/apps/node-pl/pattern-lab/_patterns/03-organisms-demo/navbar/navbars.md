| Name              | Type   | Options | Description                          |
| ----------------- | ------ | ------- | ------------------------------------ |
| navbar_classes    | String | any     | The html classes for the navbar.     |
| navbar_brand_link | String | any     | The URL the brand text will link to. |
| navbar_brand_text | String | any     | The text of the brand.               |
| navbar_id         | String | any     | The html id for the navbar           |
