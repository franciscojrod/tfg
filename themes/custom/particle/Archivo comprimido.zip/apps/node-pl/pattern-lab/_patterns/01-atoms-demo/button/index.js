import twig from './buttons.twig';
import markdown from './buttons.md';
import yaml from './buttons.yml';

export default {
  twig,
  markdown,
  yaml,
};
