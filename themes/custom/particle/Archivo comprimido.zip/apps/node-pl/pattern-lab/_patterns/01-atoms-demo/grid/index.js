import gridDemo from './grid-demo.twig';
import layoutDemo from './layout-demo.twig';

export default {
  gridDemo,
  layoutDemo,
};
