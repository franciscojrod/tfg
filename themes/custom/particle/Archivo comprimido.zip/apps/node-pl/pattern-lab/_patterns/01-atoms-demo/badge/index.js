import twig from './badges.twig';
import markdown from './badges.md';
import yaml from './badges.yml';

export default {
  twig,
  markdown,
  yaml,
};
