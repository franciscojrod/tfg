import twig from './breadcrumbs.twig';
import yaml from './breadcrumbs.yml';

export default {
  twig,
  yaml,
};
