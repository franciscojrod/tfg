import twig from './dropdowns.twig';
import markdown from './dropdowns.md';
import yaml from './dropdowns.yml';

export default {
  twig,
  markdown,
  yaml,
};
