import twig from './cards.twig';
import yaml from './cards.yml';

export default {
  twig,
  yaml,
};
