import twig from './alerts.twig';
import yaml from './alerts.yml';

export default {
  twig,
  yaml,
};
