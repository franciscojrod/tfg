import twig from './articles.twig';

export default {
  twig,
};
