import twig from './carousels.twig';
import yaml from './carousels.yml';

export default {
  twig,
  yaml,
};
