import twig from './accordions.twig';
import yaml from './accordions.yml';

export default {
  twig,
  yaml,
};
