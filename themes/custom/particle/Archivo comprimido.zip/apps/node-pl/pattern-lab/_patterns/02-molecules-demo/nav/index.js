import twig from './navs.twig';
import markdown from './navs.md';
import yaml from './navs.yml';

export default {
  twig,
  markdown,
  yaml,
};
