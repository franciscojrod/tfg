import twig from './brandings.twig';

export default {
  twig,
};
