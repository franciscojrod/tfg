import twig from './paginations.twig';
import yaml from './paginations.yml';

export default {
  twig,
  yaml,
};
