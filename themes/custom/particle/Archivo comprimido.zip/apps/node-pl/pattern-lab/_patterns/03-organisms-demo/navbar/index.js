import twig from './navbars.twig';
import markdown from './navbars.md';
import yaml from './navbars.yml';

export default {
  twig,
  markdown,
  yaml,
};
